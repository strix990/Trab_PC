import java.util.concurrent.locks.{Lock, ReentrantLock}

object L3 extends App {

  val lockt1: Lock = new ReentrantLock()

  def log(msg: String): Unit = {
    println(s"${Thread.currentThread.getName}: $msg")
  }
  def dummy(a: Int): Unit = {
    if(a == 1) {
        log("Despite all my rage, I'm just a non critical dummy")
        Thread.sleep(3000)
    }
    if(a == 2) {
        log("Despite all my rage, I'm just a critical dummy")
        Thread.sleep(3000)
    }
  }

  val t1 = new Thread {
    override def run() = {
      for (i <- 0 to 3) {
        // log("Seção não crítica")
        // dummy(1)
        // log("Sair da seção não crítica")
        lockt1.lock()
        try{
            log("Seção crítica")
            dummy(2)
        } 
        finally {
            log("Sair da seção crítica")
            lockt1.unlock()
        }
      }
    }
  }

  val t2 = new Thread {
    override def run() = {
      for (i <- 0 to 3) {
        // log("Seção não crítica")
        // dummy(1)
        // log("Sair da seção não crítica")
        lockt1.lock()
        try{
            log("Seção crítica")
            dummy(2)
        } 
        finally {
            log("Sair da seção crítica")
            lockt1.unlock()
        }
      }
    }
  }

  t1.start()
  log("Started thread1")
  t2.start()
  log("Started thread2")

  t1.join()
  log("Finished thread1")
  t2.join()
  log("Finished thread2")
}