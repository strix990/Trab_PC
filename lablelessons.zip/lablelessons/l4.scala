import java.util.concurrent.atomic.AtomicBoolean

object l4 extends App {
  
  val atomicBoolean = new AtomicBoolean(false)

  def log(msg: String): Unit = {
    println(s"${Thread.currentThread.getName}: $msg")
  }
  def dummy(a: Int): Unit = {
    if(a == 1) {
        log("Despite all my rage, I'm just a non critical dummy")
        Thread.sleep(2000)
    }
    if(a == 2) {
        log("Despite all my rage, I'm just a critical dummy")
        Thread.sleep(2000)
    }
  }

  val t1 = new Thread {
    override def run() = {
      for (i <- 0 to 3) {
        // log("Seção não crítica")
        // dummy(1)
        // log("Sair da seção não crítica")
        if(atomicBoolean.get()) {
            log("Seção crítica")
            dummy(2)
            log("Sair da seção crítica")
            atomicBoolean.set(false)
        }
        Thread.sleep(5000)
      }
    }
  }

  val t2 = new Thread {
    override def run() = {
      for (i <- 0 to 3) {
        // log("Seção não crítica")
        // dummy(1)
        // log("Sair da seção não crítica")
        if(!atomicBoolean.get()) {
            log("Seção crítica")
            dummy(2)
            log("Sair da seção crítica")
            atomicBoolean.set(true)
        }
        Thread.sleep(5000)
      }
    }
  }

  t1.start()
  log("Started thread1")
  t2.start()
  log("Started thread2")

  t1.join()
  log("Finished thread1")
  t2.join()
  log("Finished thread2")
}