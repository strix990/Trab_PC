object L2 extends App {

  def log(msg: String): Unit = {
    println(s"${Thread.currentThread.getName}: $msg")
  }
  def dummy(a: Int): Unit = {
    if(a == 1) {
        log("Despite all my rage, I'm just a non critical dummy")
        Thread.sleep(2000)
    }
    if(a == 2) {
        log("Despite all my rage, I'm just a critical dummy")
        Thread.sleep(2000)
    }
  }

  var b1: Boolean = false
  var b2: Boolean = false
  var k: Int = 1

  val t1 = new Thread {
    override def run() = {
      for (i <- 0 to 3) {
        // Seção não crítica
        log("Seção não crítica")
        dummy(1)
        log("Sair da seção não crítica")
        // Indicar intenção de entrar na seção crítica
        b1 = true
        //log("b1 = true")
        
        // Espera pela vez
        while (k != 1) {
          while (b2) {
            //log("Esperando b2 ser false")
            Thread.sleep(100) // Espera ocupada
          }
          k = 1
        }
        
        // Seção crítica
        log("Seção crítica")
        dummy(2)
        log("Sair da seção crítica")
        // Sair da seção crítica
        b1 = false
        //log("b1 = false")
      }
    }
  }

  val t2 = new Thread {
    override def run() = {
      for (i <- 0 to 3) {
        // Seção não crítica
        log("Seção não crítica")
        dummy(1)
        log("Sair da seção não crítica")

        // Indicar intenção de entrar na seção crítica
        b2 = true
        //log("b2 = true")

        // Espera pela vez
        while (k != 2) {
          while (b1) {
            //log("Esperando b1 ser false")
            Thread.sleep(100) // Espera ocupada
          }
          k = 2
        }
        
        // Seção crítica
        log("Seção crítica")
        dummy(2)
        log("Sair da seção crítica")
        // Sair da seção crítica
        b2 = false
        //log("b2 = false")
      }
    }
  }

  t1.start()
  log("Started thread1")
  t2.start()
  log("Started thread2")

  t1.join()
  log("Finished thread1")
  t2.join()
  log("Finished thread2")
}