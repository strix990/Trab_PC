package cp.lablessons.lesson1

object HelloWorld extends App {
    def compose[A, B, C](g: B => C, f: A => B): A => C = x=>  g(f(x))
    def g(x:Int):Int = x*2
    def f: Int => Int = x=>x*3
    val h = f compose g
    println(h(30));
}